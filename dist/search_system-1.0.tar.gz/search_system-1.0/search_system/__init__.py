#!/usr/bin/python3

from .search_system import Index
from .app import start
